<blockquote class="twitter-tweet"><p lang="en" dir="ltr">How to get rich:<br><br>1. Learn from a rich person. <br>2. Use what you learn. <br><br>Don&#39;t complicate it.</p>&mdash; Steffan Thorn (@SteeTweets) <a href="https://twitter.com/SteeTweets/status/1522526061111746561?ref_src=twsrc%5Etfw">May 6, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

**Format:**
- How to ***
- Steps
- Don't complicate it