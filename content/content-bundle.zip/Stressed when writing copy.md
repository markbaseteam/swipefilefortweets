<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Stressed when writing copy?<br>Here’s what you do:<br><br>1. Have a swipe file.<br>2. Find 3-5 direct competitors.<br>3. Find 5-10 indirect competitors.<br>4. Start writing ANYTHING without judging yourself.<br><br>You’ll de-stress…<br>And your subconscious will take over.<br><br>Bookmark this ☝️</p>&mdash; George Ten (@GrammarHippy) <a href="https://twitter.com/GrammarHippy/status/1532416433501745152?ref_src=twsrc%5Etfw">June 2, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

**Format:**
- Problem
- Solution
- Effect of the solution

