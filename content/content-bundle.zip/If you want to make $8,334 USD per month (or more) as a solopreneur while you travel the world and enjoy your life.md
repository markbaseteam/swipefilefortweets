<blockquote class="twitter-tweet"><p lang="en" dir="ltr">If you want to make $8,334 USD/month (or more) as a solopreneur while you travel the world and enjoy your life, read this:</p>&mdash; Eddy Quan (@waronweakness) <a href="https://twitter.com/waronweakness/status/1535613834689380353?ref_src=twsrc%5Etfw">June 11, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

**Format:**
- Desire
- As a?



