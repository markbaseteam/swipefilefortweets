<blockquote class="twitter-tweet"><p lang="en" dir="ltr">If you want to be productive, try Burkeman&#39;s 3-3-3 Method:</p>&mdash; Ben Meer (@SystemSunday) <a href="https://twitter.com/SystemSunday/status/1521829188570910721?ref_src=twsrc%5Etfw">May 4, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

**Format:**
- If you want to be ***outcome***, try ***solution***.